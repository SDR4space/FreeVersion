// 00965 TRANSIT 5B-5 136.659
var stream_name = '200k';
var frequency= 136.659;
var subband_bw= 22050;
var offset= 0;
var nb_samples=10e6;
