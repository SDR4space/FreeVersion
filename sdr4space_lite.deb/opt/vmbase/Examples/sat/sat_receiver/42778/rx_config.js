// 42778 MAX VALIER SAT   145.960
var stream_name = '200k';
var frequency= 145.930;
var subband_bw= 22050;
var offset= 28.5e3;
var nb_samples=10e6;
var demod='M USB 2800'
