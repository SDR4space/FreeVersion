// SARAL  39086 465.9875 (ARGOS)
var stream_name = '200k';
var frequency= 465.8875;
var subband_bw= 22050;
var offset= 99e3;
var nb_samples=10e6;
var demod='M USB 2800'
