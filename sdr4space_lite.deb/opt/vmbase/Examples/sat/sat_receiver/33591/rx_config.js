//NOAA19 137.100
var frequency= 137.0;
var subband_bw= 48000;
var offset= 100e3;
var nb_samples=11e6;
var demod='M FM 34000';
