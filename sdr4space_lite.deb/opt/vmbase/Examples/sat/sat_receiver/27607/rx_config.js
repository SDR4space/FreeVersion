// 27607    SO-50 CW 436.795
var stream_name = '200k';
var frequency= 436.750;
var subband_bw= 24000;
var offset= 45000;
var nb_samples=7e6;
//file_format=".cs16";

