// METOP-A 29499 465.9875 (ARGOS)

var frequency= 465.9475;
var subband_bw= 22050;
var offset= 38e3;
var nb_samples=10e6;
var demod='M USB 2800';
