// ISS 145.825
var stream_name = '200k';
var frequency= 145.725;
var subband_bw= 22050;
var offset= 100e3;
var nb_samples=10e6;
var demod='M FM 8000';
