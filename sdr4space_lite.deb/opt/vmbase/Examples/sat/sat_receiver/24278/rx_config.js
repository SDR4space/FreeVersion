//FO-29 CW 435.795
var stream_name = '200k';
var frequency= 435.750;
var subband_bw= 24000;
var offset= 45000;
var nb_samples=3e6;
//file_format=".cs16";

