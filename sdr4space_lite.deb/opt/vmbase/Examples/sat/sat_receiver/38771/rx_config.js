// 38771 METOPS-B  465.9875 (ARGOS)

var frequency= 465.9875;
var subband_bw= 22050;
var offset= 0;
var nb_samples=10e6;
