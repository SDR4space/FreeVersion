//NOAA15 137.620
var frequency= 137.500;
var subband_bw= 48000;
var offset= 120e3;
var nb_samples=10e6;
var demod='M FM 34000';
