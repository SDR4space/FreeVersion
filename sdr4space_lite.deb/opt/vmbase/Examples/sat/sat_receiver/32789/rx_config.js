// DELFI 
var stream_name = '200k';
var frequency= 145.840;
var subband_bw= 48000;
var offset= 27000;
var nb_samples=15e6;
