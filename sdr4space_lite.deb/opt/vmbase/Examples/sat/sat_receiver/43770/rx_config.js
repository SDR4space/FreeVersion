// 43770 FOX-1C  145.920
var stream_name = '200k';
var frequency= 145.0;
var subband_bw= 22050;
var offset= 20000;
var nb_samples=12e6;
var elev_record_start=15;
