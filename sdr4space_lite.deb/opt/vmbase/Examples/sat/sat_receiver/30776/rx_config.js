//Falconsat-3 435.103
var stream_name = '200k';
var frequency= 435.09;
var subband_bw= 48000;
var offset= 43000;
var nb_samples=10e6;
