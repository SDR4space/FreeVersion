var stream_name = '200k';
var frequency= 137.88;
var subband_bw= 80000;
var offset= 31250;
var nb_samples=10e6;
