// ELFIN-A
var frequency= 437445000;
var subband_bw= 24000;
var offset= 5000;
var nb_samples=10e6;
