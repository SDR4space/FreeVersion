// UVQSAT 437.020
var stream_name = '200k';
var frequency= 437.020;
var subband_bw= 48000;
var offset= 0;
var nb_samples=10e6;
