// FUNCUBE1 39444 145.935 BPSK1200
var frequency= 145.835;
var subband_bw= 48000;
var offset= 100e3;
var nb_samples= 10e6;
var elev_record_start = 10;
var demod='M FM 8000';
