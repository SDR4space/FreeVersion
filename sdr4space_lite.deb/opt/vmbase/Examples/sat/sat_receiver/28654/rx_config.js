//NOAA18 137.9125 
var frequency= 137.9125;
var subband_bw= 48000;
var offset= 0;
var nb_samples= 10e6;
var elev_record_start = 5;
var demod='M FM 34000';
