//METEOR M2 127.100
var stream_name = '200k';
var frequency= 137.1;
var subband_bw= 100000;
var offset= 0;
var nb_samples=10e6;
