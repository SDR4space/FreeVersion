// 43689 METOP-C  465.9875 (ARGOS)
var stream_name = '200k';
var frequency= 465.9575;
var subband_bw= 22050;
var offset= 28.5e3;
var nb_samples=10e6;
var demod='M USB 2800';

